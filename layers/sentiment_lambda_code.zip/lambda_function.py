# lambda_function.py
import os
import json
import numpy as np
import onnxruntime
from tokenizers import Tokenizer

onnx_session = None
tokenizer_obj = None
model_config_data = None # Store the whole config for potential future use
max_seq_length = 128    # Default, will be overridden from config
id2label_mapping = {}
pad_token_val = 0       # Default, will be overridden

MODEL_FILES_DIR_NAME = "emo_mobilebert_onnx"

def _initialize_resources():

    global onnx_session, tokenizer_obj, model_config_data, max_seq_length, id2label_mapping, pad_token_val
    
    if onnx_session is not None:
        return

    try:
        print("Initializing resources (cold start or new container)...")
        base_path = "/var/task/" # Root of your deployment package in Lambda
        model_assets_path = os.path.join(base_path, MODEL_FILES_DIR_NAME)

        print(f"Looking for model assets in: {model_assets_path}")

        config_file = os.path.join(model_assets_path, "config.json")
        if not os.path.exists(config_file):
            raise FileNotFoundError(f"config.json not found at {config_file}")
        with open(config_file, 'r', encoding='utf-8') as f:
            model_config_data = json.load(f)

        id2label_mapping = {int(k): v for k, v in model_config_data.get("id2label", {}).items()}
        if not id2label_mapping:
            raise ValueError("id2label mapping not found or empty in config.json.")
        max_seq_length = model_config_data.get("max_position_embeddings", 128)
        print(f"Loaded config: id2label has {len(id2label_mapping)} entries, max_seq_length={max_seq_length}")

        tokenizer_file_path = os.path.join(model_assets_path, "tokenizer.json")
        if not os.path.exists(tokenizer_file_path):
            raise FileNotFoundError(f"tokenizer.json not found at {tokenizer_file_path}")
        tokenizer_obj = Tokenizer.from_file(tokenizer_file_path)

        pad_token_val = tokenizer_obj.token_to_id("[PAD]")
        if pad_token_val is None:
            print("Warning: '[PAD]' token ID not explicitly found, defaulting to 0.")
            pad_token_val = 0
        
        tokenizer_obj.enable_truncation(max_length=max_seq_length)
        tokenizer_obj.enable_padding(
            direction='right', length=max_seq_length,
            pad_id=pad_token_val, pad_token='[PAD]', pad_type_id=0
        )
        print("Tokenizer loaded and configured.")

        onnx_model_file_path = os.path.join(model_assets_path, "model.onnx")
        if not os.path.exists(onnx_model_file_path):
            raise FileNotFoundError(f"model.onnx not found at {onnx_model_file_path}")
        
        onnx_session = onnxruntime.InferenceSession(
            onnx_model_file_path,
            providers=['CPUExecutionProvider']
        )
        print("ONNX model session created successfully.")
        print("All resources initialized.")

    except Exception as e:
        print(f"ERROR during resource initialization: {str(e)}")
        raise RuntimeError(f"Failed to initialize resources: {str(e)}")


def classify_sentence_with_onnx(sentence_text: str):
    """
    Performs sentiment classification on a single sentence using the loaded ONNX model and tokenizer.
    """
    if onnx_session is None:
        _initialize_resources()

    encoded_input = tokenizer_obj.encode(sentence_text)

    input_ids = np.array([encoded_input.ids], dtype=np.int64)
    attention_mask = np.array([encoded_input.attention_mask], dtype=np.int64)
    token_type_ids = np.array([encoded_input.type_ids], dtype=np.int64)

    onnx_inputs = {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "token_type_ids": token_type_ids
    }

    onnx_outputs = onnx_session.run(None, onnx_inputs)
    logits = onnx_outputs[0]

    exp_logits = np.exp(logits - np.max(logits, axis=-1, keepdims=True)) # Stability
    probabilities = exp_logits / np.sum(exp_logits, axis=-1, keepdims=True)
    
    sentence_probs = probabilities[0]

    predicted_class_index = np.argmax(sentence_probs)
    predicted_class_label = id2label_mapping.get(predicted_class_index, "Unknown")
    prediction_confidence = float(sentence_probs[predicted_class_index])

    return {
        "predicted_label": predicted_class_label,
        "confidence_score": prediction_confidence,
        "details": {id2label_mapping.get(i, f"ID_{i}"): float(p) for i, p in enumerate(sentence_probs)}
    }


def lambda_handler(event, context):
    """
    Main AWS Lambda handler function.
    Input event: Expects a JSON object like {"sentence": "Your text here"}
                 or can be a raw string for testing.
    """
    try:
        _initialize_resources()
    except RuntimeError as init_error: # Catch errors from our initialization
        print(f"Critical Error: Resource initialization failed: {str(init_error)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Resource initialization failed', 'details': str(init_error)})
        }

    print(f"Lambda handler invoked. Event: {event}")

    sentence = None
    if isinstance(event, dict) and 'sentence' in event:
        sentence = event['sentence']
    elif isinstance(event, str):
        sentence = event
    else:
        print("Error: Invalid input format.")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': "Invalid input. Expecting JSON with 'sentence' key or a raw sentence string."})
        }

    if not sentence or not isinstance(sentence, str) or len(sentence.strip()) == 0:
        print("Error: Sentence is empty or not a string.")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': "Input 'sentence' must be a non-empty string."})
        }
    
    print(f"Processing sentence: '{sentence}'")
    
    try:
        classification_result = classify_sentence_with_onnx(sentence)
        print(f"Classification result: {classification_result}")
        return {
            'statusCode': 200,
            'body': json.dumps(classification_result)
        }
    except Exception as e:
        print(f"ERROR during classification: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to classify sentence', 'details': str(e)})
        }